// import PrivateRoute from "../../routes/index.js";

const ProfilePage = () => {
  return (
    <div>
      <h1>Página de perfil</h1>
      <p>Contenido de la página de perfil</p>
    </div>
  );
};

export default ProfilePage;
